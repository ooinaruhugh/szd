#include <iostream>
#include <fstream>

#include "zip.h"

const int readBufferSize = 512;
char searchBuffer[4];

int main(int argc, char const ** argv) {
    if (!(argc > 1)) {
        std::cout << "Argument is missing" << std::endl;
        exit(EXIT_FAILURE);
    }

    std::streampos central_directory;

    std::ifstream zipfile{argv[1], std::ifstream::ate | std::ifstream::binary};
    // std::ifstream zipfile{argv[1], std::ifstream::binary};

    central_directory = zipfile.tellg() - 4;
    zipfile.seekg(central_directory);

    zipfile.read(searchBuffer, 4);

    std::cout << central_directory << std::hex << std::endl;
    for (char  b : searchBuffer) {
        std::cout << (int)b;
    }
    std::cout << std::endl;

    return 0;
}